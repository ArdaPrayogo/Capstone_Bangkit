package com.dicoding.bangkit_caps.ui.kuis

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.dicoding.bangkit_caps.R

class KuisionerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kuisioner)
    }
}