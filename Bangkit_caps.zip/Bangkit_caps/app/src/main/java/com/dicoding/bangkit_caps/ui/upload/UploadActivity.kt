package com.dicoding.bangkit_caps.ui.upload

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.dicoding.bangkit_caps.R
import com.dicoding.bangkit_caps.databinding.ActivityUploadBinding
import com.dicoding.bangkit_caps.pref.reduceFileImage
import com.dicoding.bangkit_caps.pref.rotateFile
import com.dicoding.bangkit_caps.pref.uriToFile
import java.io.File

class UploadActivity : AppCompatActivity() {

    private var getFile: File? = null
    private lateinit var binding: ActivityUploadBinding

    companion object {
        const val CAMERA_X_RESULT = 200

        private val REQUIRED_PERMISSION = arrayOf(android.Manifest.permission.CAMERA)
        private const val REQUEST_CODE_PERMISSIONS = 10
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (!allPermissionsGranted()) {
                Toast.makeText(
                    this,
                    "Tidak mendapatkan permission.",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }
    private fun allPermissionsGranted() = REQUIRED_PERMISSION.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)


        if (!allPermissionsGranted()){
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSION,
                REQUEST_CODE_PERMISSIONS
            )
        }

        binding.cameraButton.setOnClickListener {
            startCamera()
        }

        binding.submitButton.setOnClickListener {
            uploadImage()
        }

    }

    private fun startCamera(){
        val  intent = Intent(this,CameraActivity::class.java)
        launcherIntentCameraX.launch(intent)
    }

    private val launcherIntentCameraX = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == CAMERA_X_RESULT) {
            val myFile = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                it.data?.getSerializableExtra("picture", File::class.java)
            } else {
                @Suppress("DEPRECATION")
                it.data?.getSerializableExtra("picture")
            } as? File
            val isBackCamera = it.data?.getBooleanExtra("isBackCamera", true) as Boolean
            myFile?.let { file ->
                rotateFile(file,isBackCamera)
                getFile = file
                binding.previewImageView.setImageBitmap(BitmapFactory.decodeFile(file.path))
            }
        }
    }

    private val launcherIntentGallery = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val selectedImg = result.data?.data as Uri
            selectedImg.let { uri ->
                val myFile = uriToFile(uri, this@UploadActivity)
                getFile = myFile
                binding.previewImageView.setImageURI(uri)
            }
        }
    }

    private fun startGallery() {
        val intent = Intent()
        intent.action = Intent.ACTION_GET_CONTENT
        intent.type = "image/*"
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launcherIntentGallery.launch(chooser)
    }

    private fun uploadImage() {
        if (getFile != null) {
            val file = reduceFileImage(getFile as File)
//            val requestImageFile = file.asRequestBody("image/jpeg".toMediaType())
//            val imageMultipart: MultipartBody.Part = MultipartBody.Part.createFormData(
//                "photo",
//                file.name,
//                requestImageFile
//            )

//            mainViewModel.getUser().observe(this){user ->
//                val uploadImageRequest = ApiConfig.getApiService().uploadStory(
//                    "Bearer ${user.token}",
//                    imageMultipart,
//                    requestBody
//                )
//                uploadImageRequest.enqueue(object : Callback<UploadResponse> {
//                    override fun onResponse(
//                        call: Call<UploadResponse>,
//                        response: Response<UploadResponse>
//                    ) {
//                        if (response.isSuccessful) {
//                            val responseBody = response.body()
//                            if (responseBody != null && !responseBody.error) {
//                                Toast.makeText(this@UploadActivity, responseBody.message, Toast.LENGTH_SHORT).show()
//                                val intent = Intent(this@UploadActivity, MainActivity::class.java)
//                                startActivity(intent)
//                                finish()
//
//                            }
//                        } else {
//                            Toast.makeText(this@UploadActivity, response.message(), Toast.LENGTH_SHORT).show()
//                        }
//                    }
//                    override fun onFailure(call: Call<UploadResponse>, t: Throwable) {
//                        Toast.makeText(this@UploadActivity, t.message, Toast.LENGTH_SHORT).show()
//                    }
//                })
//
//            }

        } else {
            Toast.makeText(this@UploadActivity,"Silakan masukkan berkas terlebih dahulu.", Toast.LENGTH_SHORT).show()
        }

    }



}